<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Praktikum Web - Layouting</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- Header Sectopm -->
     <header class="header">
        <div class="branding">
            <img src="./images/logo-fts.png" alt="logo-fts" width="100px">
            <div class="title">
                <h1>Teknik Informatika</h1>
                <p>Universitas Ibn Khaldun</p>
            </div>
        </div>
        <div>
            <marquee behavior="" direction="">
                Selamat Datang di Universitas Ibn Khaldun
            </marquee>
        </div>
     </header>

     <!-- Container Section -->
      <div class="container">
        <nav class="sidebar">
            <ul class="menu">
                <li>
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                <li>
                    <a class="nav-link" href="index.php?page=data_mahasiswa">Data Mahasiswa</a>
                </li>
                <li>
                    <a class="nav-link" href="index.php?page=data_mata_kuliah">Data Mata Kuliah</a>
                </li>
                <li>
                    <a class="nav-link" href="index.php?page=data_laboratorium">Data Laboratorium</a>
                </li>
            </ul>
        </nav>

        <main class="content">
            <?php
                $pages_dir = 'pages';
                if (!empty($_GET['page'])) {
                    $pages = scandir($pages_dir, 0);
                    unset($pages[0], $pages[1]);
                    $page = $_GET['page'];

                    if (in_array($page.'.php', $pages)) {
                        include($pages_dir.'/'.$page.'.php');
                    } 
                    else {
                        echo 'Halaman tidak ditemukan!';
                    }
                } 
                else {
                    include($pages_dir.'/home.php');
                }
            ?>
        </main>
      </div>

      <!-- Footer Section -->
       <div>
            <footer class="footer">
                <p>&copy; 2025 Universitas Ibn Khaldun. All rights reserved.</p>
       </div>

</body>
</html>